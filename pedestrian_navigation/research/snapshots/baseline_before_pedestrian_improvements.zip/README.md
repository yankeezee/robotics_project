# Pedestrian-aware navigation: development starter

Anastasiia's implementation: Webots environment, reactive baseline, scripted
scenarios, and logging. Sophia's predictive planner and final analysis are not
implemented here. Everything below is development work, not held-out evaluation.

## Start

Requirements: Webots R2025b and Python 3.10 or newer. No pip packages are needed.
The first world load downloads the official TurtleBot3 Burger model and its
assets from Cyberbotics. Its source commit is pinned in `worlds/walkway.wbt`.

In PowerShell, from this project directory:

```powershell
python -m unittest discover -s tests -v
python run.py --scenario empty
python run.py --scenario static --scenario crossing --scenario oncoming --scenario stop_turn --seed 0
python run.py --scenario crossing --show
```

Alternatively, open `worlds/walkway.wbt` in Webots and press Run. The default
configuration runs one empty-scene case and pauses after completion. Edit
`config/development.json` to choose a different development case. Batch launches
use a separate configuration, close their own simulator after completion, and
do not modify the default configuration.

The launcher uses the Python interpreter that starts `run.py`. For direct GUI
launches, Webots must have a working Python command in Preferences.

## Scene and interface

- Ground plane: **x-y**; z is vertical (ENU). Robot forward is +x at yaw zero.
- Walkway: 8 m long, 2.6 m clear width; start (-3, 0), goal (3, 0).
- Wheel radius: 0.033 m; wheel separation: 0.160 m; wheel limit: 6.67 rad/s,
  matching the official model. Robot planning footprint: conservative 0.14 m circle.
- Orange cylinders: static obstacles. Blue cylinders: scripted pedestrians
  with a 0.25 m radius. Green disk: goal tolerance region.
- Supervisor privileges are enabled on the robot for this prototype. Scene
  management and observation are logically separated from the pure planner.
- `navigation/core.py`: `Observation`, `Command`, and shared `Parameters`.
  `planner.command(observation, previous_command, dt)` returns body velocities.
  Observations contain current pedestrian positions only: no future pedestrian
  paths, pedestrian waypoints, true velocities, or scenario identifiers are
  exposed to planning.
- `navigation/routing.py`: A* over the known static map with visibility smoothing.
  A static-map waypoint is included in each observation. Pedestrian script
  waypoints are never exposed. This shared guide avoids the symmetric-obstacle
  local minimum of goal-only scoring and must be identical for both variants.
- `navigation/reactive.py`: feasible velocity sampling, two-second rollout,
  current-position obstacle checks, goal/clearance/smoothness scoring, and braking
  fallback. This is a simplified experimental baseline, not full DWA.
- `navigation/scenarios.py`: deterministic development scripts for empty,
  static, crossing, oncoming, and sudden-stop/turn cases. These initial scripts
  contain zero or one pedestrian. Multiple pedestrians and held-out seeds remain
  to be added and validated before the final experiment.

For Sophia: implement a stateful planner with the same `command` interface,
estimate pedestrian velocities from current and past observations, and use the
same limits, scoring, and braking rules. Refactor shared rollout/scoring before
the comparison so the pedestrian motion model is the only experimental change.
Do not import scenario scripts into a planner.

## Results and definitions

Each launch creates a unique `results/<UTC timestamp>/` directory containing:

- `run_config.json`: resolved parameter snapshot; `webots.log` for batch runs.
- Per-trial `scenario.json`: full script for reproducibility, Supervisor use only.
- `trajectory.csv`: actual pose, speed, commands, goal distance, and clearances.
- `observations.jsonl`: exact current observations available to the planner.
- `static_route.json`: shared map-based route; `scene.png` when `--snapshot` is used.
- Per-trial and batch `summary.json`: outcome, elapsed time, path length, waiting,
  minimum clearances, and whether the pedestrian margin was violated.

Success: within 0.25 m of the goal before 120 s without a conservative geometric
collision. Collision takes priority over simultaneous success or timeout.
Collision here means overlap of the enclosing robot circle with a pedestrian,
static cylinder, or walkway wall. This deliberately conservative geometric
definition is **not** an exact physical-contact sensor. Cylinder overlaps are
also checked along relative-motion segments between simulation samples.
Waiting uses actual planar speed below 0.01 m/s. Boundary-to-boundary pedestrian
clearance below 0.20 m marks a margin violation. Empty scenes have null pedestrian
clearance, not an invented measurement. Scripted pedestrians do not yield.

Parameters are initial development choices. Do not treat these runs as the
proposal's 60 paired held-out cases or claim a predictive comparison yet.

## Verified checkpoint (November 24, 2026)

Five unit checks pass: wheel conventions, empty-scene convergence with command
limits, reproducible pedestrian motion, between-sample overlap detection, and
static-route clearance. All five development scenes also execute in Webots.
The latest seed-0 batch is saved in
`results/20261124T073024.104501Z/summary.json`:

| Development case | Outcome | Simulated time | Minimum relevant boundary clearance |
| --- | --- | ---: | ---: |
| Empty walkway | Success | 29.248 s | 1.160 m to walls |
| Static central cylinder | Success | 32.320 s | 0.310 m to static geometry |
| Crossing pedestrian | Conservative geometric collision | 14.720 s | -0.022 m to pedestrian |
| Oncoming pedestrian | Conservative geometric collision | 8.320 s | -0.009 m to pedestrian |
| Stop/turn pedestrian | Conservative geometric collision | 14.720 s | -0.022 m to pedestrian |

These are individual development runs, not performance estimates. The robot
now moves and avoids the central static obstacle. **Pedestrian avoidance is not
ready**: braking alone can leave the robot in a moving pedestrian's path, and
the current local policy needs further work. In seed 0 the stop/turn case ends
before the scripted stop, so it does not yet test the intended change of motion.
Preserve the failure logs while improving development behavior. An earlier
goal-only static baseline also timed out; the shared static-map route fixes that
observed local minimum. A verified scene snapshot is in
`results/20261124T072835.738919Z/00_static_seed0/scene_preview.png`.

## Next work

1. Inspect failing pedestrian trajectories and improve reactive avoidance and
   the shared emergency-braking rule without exposing future scripted paths.
2. Make the stop/turn development case reach its motion-change event; review
   geometry and collision definitions together before fixing the final protocol.
3. Add 2--5 pedestrian cases, varied offsets, and separate development/test seeds.
4. Integrate Sophia's predictor, freeze shared settings, then run paired evaluation.

Official references:
- [TurtleBot3 Burger model](https://github.com/cyberbotics/webots/blob/d42e42bfe9a9f3c634cf318d9452eb92c487625a/projects/robots/robotis/turtlebot/protos/TurtleBot3Burger.proto)
- [Supervisor API](https://cyberbotics.com/doc/reference/supervisor)
