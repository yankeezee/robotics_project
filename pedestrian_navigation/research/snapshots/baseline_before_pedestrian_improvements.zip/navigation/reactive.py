"""Reactive velocity-sampling baseline; pedestrian positions stay fixed in rollout.

This is an experimental local planner, not a full DWA implementation or a
stopping-safety guarantee. No future pedestrian paths enter this module.
"""
import math
from .core import Command, Observation, Parameters, advance, brake, clearance, wheel_speeds


def samples(low: float, high: float, count: int) -> list[float]:
    return [low + (high - low) * i / (count - 1) for i in range(count)]


class ReactivePlanner:
    def __init__(self, parameters: Parameters):
        self.p = parameters

    def command(self, observation: Observation, previous: Command, dt: float) -> Command:
        p = self.p
        if math.hypot(observation.goal[0] - observation.pose.x,
                      observation.goal[1] - observation.pose.y) <= p.goal_tolerance:
            return brake(previous, dt, p)
        vs = samples(max(0.0, previous.v - p.max_acceleration*dt),
                     min(p.max_speed, previous.v + p.max_acceleration*dt), 7)
        ws = samples(max(-p.max_turn_rate, previous.omega - p.max_angular_acceleration*dt),
                     min(p.max_turn_rate, previous.omega + p.max_angular_acceleration*dt), 13)
        if vs[0] == 0:
            vs.append(0.0)
        if ws[0] <= 0 <= ws[-1]:
            ws.append(0.0)
        best, best_score = brake(previous, dt, p), -math.inf
        target = observation.waypoint or observation.goal
        initial_distance = math.hypot(target[0] - observation.pose.x,
                                      target[1] - observation.pose.y)
        circles = observation.obstacles + observation.pedestrians
        for v in vs:
            for w in ws:
                cmd = Command(v, w)
                if max(map(abs, wheel_speeds(cmd, p))) > p.max_wheel_speed + 1e-9:
                    continue
                pose, minimum, feasible = observation.pose, 2.0, True
                for _ in range(math.ceil(p.horizon / p.rollout_step)):
                    pose = advance(pose, cmd, p.rollout_step)
                    gap = min(clearance(pose, circles, p.robot_radius),
                              observation.half_width - abs(pose.y) - p.robot_radius)
                    if gap < p.safety_margin:
                        feasible = False
                        break
                    minimum = min(minimum, gap)
                if not feasible:
                    continue
                remaining = math.hypot(target[0] - pose.x, target[1] - pose.y)
                heading = math.atan2(target[1] - pose.y, target[0] - pose.x)
                score = (4.0*(initial_distance - remaining) + 0.4*math.cos(heading - pose.yaw)
                         + 0.08*minimum + 0.2*v - 0.03*abs(w)
                         - 0.03*abs(w - previous.omega))
                if score > best_score:
                    best, best_score = cmd, score
        return best
