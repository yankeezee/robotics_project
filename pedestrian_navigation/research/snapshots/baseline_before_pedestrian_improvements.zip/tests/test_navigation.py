import math
import unittest
from navigation.core import Circle, Command, Observation, Parameters, Pose, advance, segment_distance, wheel_speeds
from navigation.reactive import ReactivePlanner
from navigation.routing import static_route
from navigation.scenarios import make_scenario


class NavigationChecks(unittest.TestCase):
    def test_static_route_clears_symmetric_obstacle(self):
        p, obstacle = Parameters(), Circle(0, 0, 0.25)
        points = [(-3, 0)] + static_route((-3, 0), (3, 0), (obstacle,), 1.3, p)
        self.assertEqual(points[-1], (3, 0))
        self.assertGreater(len(points), 2)
        for a, b in zip(points, points[1:]):
            distance = segment_distance((a[0]-obstacle.x, a[1]-obstacle.y),
                                        (b[0]-obstacle.x, b[1]-obstacle.y))
            self.assertGreaterEqual(distance, obstacle.radius+p.robot_radius+p.safety_margin+p.route_buffer)

    def test_differential_drive_wheel_convention(self):
        p = Parameters()
        left, right = wheel_speeds(Command(0.1, 0.5), p)
        self.assertAlmostEqual(p.wheel_radius*(left+right)/2, 0.1)
        self.assertAlmostEqual(p.wheel_radius*(right-left)/p.wheel_separation, 0.5)
        self.assertGreater(right, left)

    def test_relative_motion_detects_between_sample_crossing(self):
        self.assertAlmostEqual(segment_distance((-1, 0), (1, 0)), 0)
        self.assertAlmostEqual(segment_distance((-1, 0.5), (1, 0.5)), 0.5)

    def test_script_holds_and_seed_is_reproducible(self):
        scenario = make_scenario('stop_turn', 42)
        self.assertEqual(scenario, make_scenario('stop_turn', 42))
        pedestrian = scenario.pedestrians[0]
        start, end = pedestrian.waypoints[2][0], pedestrian.waypoints[3][0]
        before, during = pedestrian.position(start), pedestrian.position((start+end)/2)
        self.assertAlmostEqual(before.x, during.x)
        self.assertAlmostEqual(before.y, during.y)

    def test_empty_scene_reaches_goal_with_limits(self):
        p, previous, dt = Parameters(), Command(), 0.064
        planner = ReactivePlanner(p)
        pose, goal = Pose(-0.5, 0, 0), (0.5, 0)
        for tick in range(200):
            observation = Observation(tick*dt, pose, goal, (), (), 1.3)
            command = planner.command(observation, previous, dt)
            self.assertLessEqual(max(map(abs, wheel_speeds(command, p))), p.max_wheel_speed+1e-8)
            self.assertLessEqual(abs(command.v-previous.v), p.max_acceleration*dt+1e-8)
            self.assertLessEqual(abs(command.omega-previous.omega), p.max_angular_acceleration*dt+1e-8)
            pose, previous = advance(pose, command, dt), command
            if math.hypot(pose.x-goal[0], pose.y-goal[1]) <= p.goal_tolerance:
                return
        self.fail('Empty-scene goal was not reached.')


if __name__ == '__main__':
    unittest.main()
